package org.example;

public class Main {
    public static void main(String[] args) {
        StudentInteraction si = new StudentInteraction();
        si.makeInteraction();
    }
}